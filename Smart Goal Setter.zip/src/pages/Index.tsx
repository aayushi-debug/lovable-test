import { Link } from "react-router-dom";
import { AskAI, type AskAIContext } from "@/components/AskAI";
import { ArrowRight, Sparkles, Settings2, Bell } from "lucide-react";

const demoContext: AskAIContext = {
  toolName: "Demo Tool",
  scope: "account",
  availableSettings: [
    { key: "option1", label: "Option 1", type: "text", currentValue: "Default" },
    { key: "option2", label: "Option 2", type: "number", currentValue: 50, unit: "%" },
    { key: "option3", label: "Option 3", type: "boolean", currentValue: true },
  ],
  supportedActions: ["update", "reset", "apply"],
};

export default function Index() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="text-center space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-ai-surface border border-ai-border text-sm text-ai-accent">
            <Sparkles className="h-4 w-4" />
            <span>Intent Translator Component</span>
          </div>
          <h1 className="text-4xl font-bold text-foreground">
            Ask AI Component
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A reusable natural language interface for SaaS tools. Users describe their goals, 
            and AI translates them into actionable settings.
          </p>
        </div>

        {/* Live Demo */}
        <div className="mb-16">
          <div className="rounded-xl border border-border bg-card p-8">
            <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-4">
              Live Demo
            </h2>
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">Try it:</span>
              <AskAI
                context={demoContext}
                onApplyChanges={(changes) => console.log("Applied:", changes)}
                inputPlaceholder="Describe what you want to achieve..."
                helperText="AI will translate your intent into settings"
              />
            </div>
          </div>
        </div>

        {/* Use Cases */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <Link
            to="/budget-tool"
            className="group p-6 rounded-xl border border-border bg-card hover:border-ai-border hover:shadow-lg transition-all duration-200"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-success/10 text-success">
                <Settings2 className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">Budget Tool</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Optimize budget allocation with natural language. Set strategies, targets, and limits by describing your goals.
            </p>
            <div className="flex items-center gap-1 text-sm font-medium text-primary group-hover:gap-2 transition-all">
              View Demo <ArrowRight className="h-4 w-4" />
            </div>
          </Link>

          <Link
            to="/alert-creation"
            className="group p-6 rounded-xl border border-border bg-card hover:border-ai-border hover:shadow-lg transition-all duration-200"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-warning/10 text-warning">
                <Bell className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">Alert Creation</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Create KPI alerts using plain language. Define thresholds, monitoring levels, and notification preferences.
            </p>
            <div className="flex items-center gap-1 text-sm font-medium text-primary group-hover:gap-2 transition-all">
              View Demo <ArrowRight className="h-4 w-4" />
            </div>
          </Link>
        </div>

        {/* Features */}
        <div className="rounded-xl border border-border bg-card p-8">
          <h2 className="text-lg font-semibold text-foreground mb-6">Component Features</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {[
              "Collapsible CTA button with sparkle icon",
              "Smooth accordion animation",
              "Natural language input field",
              "Settings diff preview card",
              "Confidence indicators",
              "Reusable with context props",
              "TypeScript support",
              "Accessible keyboard navigation",
            ].map((feature, idx) => (
              <div key={idx} className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="h-1.5 w-1.5 rounded-full bg-success" />
                {feature}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
