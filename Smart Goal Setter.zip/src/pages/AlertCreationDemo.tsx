 import { useState } from "react";
 import { X, Copy, ChevronDown } from "lucide-react";
 import { AskAI, type AskAIContext, type SettingChange } from "@/components/AskAI";
 import { cn } from "@/lib/utils";
 
 const alertContext: AskAIContext = {
   toolName: "KPI Alert Creator",
   scope: "account",
   scopeLabel: "27 accounts",
   availableSettings: [
     {
       key: "level",
       label: "Level to Monitor",
       type: "select",
       options: [
         { value: "account", label: "Account" },
         { value: "campaign", label: "Campaign" },
         { value: "ad_group", label: "Ad Group" },
         { value: "keyword", label: "Keyword" },
       ],
       currentValue: "",
     },
     {
       key: "kpi",
       label: "KPI to Monitor",
       type: "select",
       options: [
         { value: "ctr", label: "CTR" },
         { value: "cpc", label: "CPC" },
         { value: "conversions", label: "Conversions" },
         { value: "cost", label: "Cost" },
         { value: "impressions", label: "Impressions" },
       ],
       currentValue: "",
     },
     {
       key: "threshold",
       label: "Threshold",
       type: "number",
       min: 0,
       max: 100,
       unit: "%",
       currentValue: 20,
     },
     {
       key: "trend_alert",
       label: "Alert on Trend",
       type: "boolean",
       currentValue: false,
     },
   ],
   supportedActions: ["set_kpi", "set_threshold", "set_level", "enable_trend"],
 };
 
 export default function AlertCreationDemo() {
   const [isOpen, setIsOpen] = useState(true);
   const [settings, setSettings] = useState({
     level: "",
     kpi: "",
     threshold: 20,
     trendAlert: false,
   });
 
   const handleApplyChanges = (changes: SettingChange[]) => {
     console.log("Applying alert changes:", changes);
     const newSettings = { ...settings };
     changes.forEach((change) => {
       if (change.key === "level") newSettings.level = String(change.newValue);
       if (change.key === "kpi") newSettings.kpi = String(change.newValue);
       if (change.key === "threshold") newSettings.threshold = Number(change.newValue);
       if (change.key === "trend_alert") newSettings.trendAlert = Boolean(change.newValue);
     });
     setSettings(newSettings);
   };
 
   if (!isOpen) {
     return (
       <div className="min-h-screen bg-background flex items-center justify-center">
         <button
           onClick={() => setIsOpen(true)}
           className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
         >
           Open Alert Creator
         </button>
       </div>
     );
   }
 
   return (
     <div className="min-h-screen bg-background/80 flex items-center justify-center p-4">
       {/* Modal */}
       <div className="w-full max-w-lg bg-card rounded-xl shadow-2xl border border-border overflow-hidden">
         {/* Header */}
         <div className="flex items-start justify-between p-6 border-b border-border">
           <div>
             <h2 className="text-lg font-semibold text-foreground">Create a KPI alert</h2>
             <p className="text-sm text-muted-foreground mt-1">
               Be notified whenever the KPI deviates significantly compared to the target
             </p>
           </div>
           <button
             onClick={() => setIsOpen(false)}
             className="p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
           >
             <X className="h-5 w-5" />
           </button>
         </div>
 
         {/* Content */}
         <div className="p-6 space-y-5">
           {/* Ask AI */}
           <AskAI
             context={alertContext}
             onApplyChanges={handleApplyChanges}
             inputPlaceholder="e.g. 'Alert me when CTR drops 15% at campaign level'"
             helperText="We'll configure the alert settings automatically"
           />
 
           {/* Accounts */}
           <div className="space-y-2">
             <label className="text-sm font-medium text-primary">Accounts</label>
             <div className="flex items-center gap-2 px-3 py-2 rounded-md border border-border bg-muted/30">
               <span className="text-sm text-foreground">249-403-3111 +26 more</span>
               <Copy className="h-4 w-4 text-muted-foreground ml-auto" />
             </div>
           </div>
 
           {/* Level to monitor */}
           <div className="space-y-2">
             <label className="text-sm font-medium text-primary">Level to monitor</label>
             <button className="w-full flex items-center justify-between px-3 py-2 rounded-md border border-border bg-card hover:bg-muted/30 transition-colors">
               <span className={cn("text-sm", settings.level ? "text-foreground" : "text-muted-foreground")}>
                 {settings.level || "Select level"}
               </span>
               <ChevronDown className="h-4 w-4 text-muted-foreground" />
             </button>
           </div>
 
           {/* KPI to monitor */}
           <div className="space-y-2">
             <label className="text-sm font-medium text-primary">KPI to monitor</label>
             <button className="w-full flex items-center justify-between px-3 py-2 rounded-md border border-border bg-card hover:bg-muted/30 transition-colors">
               <span className={cn("text-sm", settings.kpi ? "text-foreground" : "text-muted-foreground")}>
                 {settings.kpi || "Select KPI"}
               </span>
               <ChevronDown className="h-4 w-4 text-muted-foreground" />
             </button>
           </div>
 
           {/* Target */}
           <div className="space-y-3">
             <label className="text-sm font-medium text-muted-foreground">Target:</label>
             
             <div className="flex items-center gap-2">
               <input type="radio" id="relative" name="target" defaultChecked className="text-primary" />
               <label htmlFor="relative" className="text-sm text-foreground flex items-center gap-2 flex-wrap">
                 Alert me when metric decreases or increases by more than
                 <input
                   type="number"
                   value={settings.threshold}
                   onChange={(e) => setSettings({ ...settings, threshold: Number(e.target.value) })}
                   className="w-16 px-2 py-1 text-sm text-center rounded border border-primary/30 bg-primary/5 focus:outline-none focus:ring-1 focus:ring-primary"
                 />
                 % based on the last 28 days.
               </label>
             </div>
 
             <div className="flex items-start gap-2">
               <input type="radio" id="absolute" name="target" className="mt-1 text-primary" />
               <label htmlFor="absolute" className="text-sm text-muted-foreground">
                 Alert me when metric drops below or increases above a fixed value, with a buffer to account for slight changes.
               </label>
             </div>
           </div>
 
           {/* Trend */}
           <div className="space-y-2">
             <label className="text-sm font-medium text-muted-foreground">Trend:</label>
             <div className="flex items-start gap-2">
               <input
                 type="checkbox"
                 id="trend"
                 checked={settings.trendAlert}
                 onChange={(e) => setSettings({ ...settings, trendAlert: e.target.checked })}
                 className="mt-0.5"
               />
               <label htmlFor="trend" className="text-sm text-muted-foreground">
                 Additionally, alert me when metric is trending the wrong way, even when within the target range.
               </label>
             </div>
           </div>
         </div>
 
         {/* Footer */}
         <div className="flex items-center justify-end gap-3 p-6 border-t border-border bg-muted/30">
           <button
             onClick={() => setIsOpen(false)}
             className="px-4 py-2 text-sm font-medium rounded-md border border-border text-foreground hover:bg-muted transition-colors"
           >
             Cancel
           </button>
           <button className="px-4 py-2 text-sm font-medium rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors">
             Add
           </button>
         </div>
       </div>
     </div>
   );
 }