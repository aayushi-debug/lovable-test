import { useState } from "react";
import { AskAIInline, type AskAIContext, type SettingChange } from "@/components/AskAI";
import { ChevronDown, Filter, Settings2, CheckSquare, Edit2 } from "lucide-react";
import { cn } from "@/lib/utils";

const budgetContext: AskAIContext = {
  toolName: "Budget Optimizer",
  scope: "portfolio",
  scopeLabel: "8 budgets selected",
  availableSettings: [
    {
      key: "strategy",
      label: "Strategy",
      type: "select",
      options: [
        { value: "smart", label: "Smart Strategy" },
        { value: "maximize_conversions", label: "Maximize Conversions" },
        { value: "target_cpa", label: "Target CPA" },
        { value: "target_roas", label: "Target ROAS" },
      ],
      currentValue: "smart",
    },
    {
      key: "target_spend",
      label: "Target Spend",
      type: "number",
      min: 0,
      max: 100000,
      unit: "$",
      currentValue: 10000,
    },
    {
      key: "budget_limit_min",
      label: "Min Budget Change",
      type: "number",
      min: -100,
      max: 0,
      unit: "%",
      currentValue: -30,
    },
    {
      key: "budget_limit_max",
      label: "Max Budget Change",
      type: "number",
      min: 0,
      max: 200,
      unit: "%",
      currentValue: 100,
    },
  ],
  supportedActions: ["adjust_budget", "change_strategy", "set_limits", "apply_to_selection"],
};

// Sample budget data
const budgets = [
  { name: "PPC Solutions - US & Canada", channel: "Search", period: "Daily", current: 100, new: 200, change: 100, cost: 483 },
  { name: "Optmyzr - PPC Tool - MENA", channel: "Search", period: "Daily", current: 30, new: 60, change: 100, cost: 137 },
  { name: "Optmyzr - Brand", channel: "Search", period: "Daily", current: 150, new: 106, change: -29.3, cost: 123 },
  { name: "Competitors", channel: "Search", period: "Daily", current: 75, new: 53, change: -29.3, cost: 104 },
  { name: "Optmyzr - Brand - Europe", channel: "Search", period: "Daily", current: 100, new: 70, change: -30, cost: 103 },
];

export default function BudgetToolDemo() {
  const [settings, setSettings] = useState({
    strategy: "smart",
    targetSpend: 10000,
    minLimit: -30,
    maxLimit: 100,
  });

  const handleApplyChanges = (changes: SettingChange[]) => {
    console.log("Applying changes:", changes);
    const newSettings = { ...settings };
    changes.forEach((change) => {
      if (change.key === "strategy") {
        newSettings.strategy = String(change.newValue);
      }
      if (change.key === "target_spend") {
        newSettings.targetSpend = Number(change.newValue);
      }
      if (change.key === "budget_limit_min") {
        newSettings.minLimit = Number(change.newValue);
      }
      if (change.key === "budget_limit_max") {
        newSettings.maxLimit = Number(change.newValue);
      }
    });
    setSettings(newSettings);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <h1 className="text-xl font-semibold text-foreground">Budget Control Center</h1>
          <p className="text-sm text-muted-foreground">Plan, optimize, and monitor your budgets in one place.</p>
        </div>
      </div>

      {/* Info Banner */}
      <div className="bg-primary/5 border-b border-primary/10">
        <div className="max-w-7xl mx-auto px-6 py-2">
          <p className="text-sm text-muted-foreground">
            <span className="text-primary font-medium">ℹ️</span> Use the <span className="font-medium text-foreground">Budget Dashboard</span> for analysis and <span className="font-medium text-foreground">Optimize Budgets</span> for smart reallocation suggestions.
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-6">
            <button className="py-3 text-sm text-muted-foreground hover:text-foreground transition-colors">
              Budget Dashboard
            </button>
            <button className="py-3 text-sm font-medium text-foreground border-b-2 border-primary">
              Optimize Budgets
            </button>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-start justify-between gap-6 mb-4">
          {/* Left: Filters */}
          <div className="flex items-center gap-4">
            <button className="inline-flex items-center gap-2 px-3 py-1.5 text-sm rounded-md border border-border bg-card hover:bg-muted transition-colors">
              <Filter className="h-4 w-4" />
              Budgets Included: Enabled only
            </button>
            <button className="text-sm text-primary hover:underline">More Filters</button>
          </div>

          {/* Right: Cycle selector and Apply */}
          <div className="flex items-center gap-4">
            <button className="inline-flex items-center gap-2 px-3 py-1.5 text-sm rounded-md border border-border bg-card hover:bg-muted transition-colors">
              This Budget Cycle
              <ChevronDown className="h-4 w-4" />
            </button>
            <button className="px-4 py-2 text-sm font-medium rounded-md bg-success text-success-foreground hover:bg-success/90 transition-colors">
              Apply Changes
            </button>
          </div>
        </div>

        {/* Ask AI Inline with settings panel as overlay target */}
        <AskAIInline
          context={budgetContext}
          onApplyChanges={handleApplyChanges}
          helperText="We'll convert this into budget optimization settings"
          className="mb-4"
        >
          {/* Settings Panel - rendered as children so preview overlays on it */}
          <div className="p-4 border border-border bg-card rounded-lg">
            <div className="flex items-start gap-8">
              {/* Strategy & Target Column */}
              <div className="flex flex-col gap-2 min-w-[280px]">
                <div className="flex items-center gap-4">
                  <div>
                    <span className="text-xs text-muted-foreground block mb-1">Select Strategy</span>
                    <button className="flex items-center gap-2 px-3 py-1.5 text-sm rounded-md border border-border bg-background hover:bg-muted transition-colors">
                      <Settings2 className="h-4 w-4" />
                      {settings.strategy === "smart" ? "Smart Strategy" : settings.strategy}
                      <ChevronDown className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-primary/10 rounded-md border border-primary/20">
                    <CheckSquare className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium">Hit a Target Budget of <span className="text-primary">${settings.targetSpend.toLocaleString()}</span></span>
                    <span className="text-xs px-1.5 py-0.5 bg-success/20 text-success rounded font-medium">NEW</span>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="text-primary hover:underline cursor-pointer">Advanced Budget Limits</span>
                  <span>Per Budget: {settings.minLimit}% to +{settings.maxLimit}%</span>
                  <button className="inline-flex items-center gap-1 text-primary hover:underline">
                    <Edit2 className="h-3 w-3" /> Edit Limits
                  </button>
                </div>
              </div>

              {/* Divider */}
              <div className="h-16 w-px bg-border" />

              {/* Stats Columns */}
              <div className="flex gap-8">
                <div>
                  <span className="text-xs text-muted-foreground block mb-1">New Projected Spend</span>
                  <span className="text-xs text-muted-foreground block">Feb 01 → Feb 28</span>
                  <p className="text-lg font-semibold text-foreground">$9,631 <span className="text-muted-foreground font-normal text-sm">(96% of target)</span></p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground block mb-1">Current Projected Spend</span>
                  <span className="text-xs text-muted-foreground block">Feb 01 → Feb 28</span>
                  <p className="text-lg font-semibold text-foreground">$6,659 <span className="text-muted-foreground font-normal text-sm">(67% of target)</span></p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground block mb-1">Spend Till Now</span>
                  <span className="text-xs text-muted-foreground block">Feb 01 → Feb 09</span>
                  <p className="text-lg font-semibold text-foreground">$1,862 <span className="text-muted-foreground font-normal text-sm">(19% of target)</span></p>
                </div>
              </div>
            </div>
          </div>
        </AskAIInline>
      </div>

      {/* Impact Banner */}
      <div className="max-w-7xl mx-auto px-6">
        <div className="p-4 rounded-lg bg-ai-surface border border-ai-border">
          <p className="text-sm">
            <span className="font-medium text-foreground">IMPACT:</span>{" "}
            <span className="text-muted-foreground">
              The projected spend will increase from $6,659 to{" "}
              <span className="font-medium text-foreground">$9,631</span>{" "}
              <span className="text-success">(+44.6%)</span>, which is the maximum achievable amount. This is expected to boost <span className="font-medium">Clicks</span> by <span className="text-success">+38.6%</span> based on recent performance trends.
            </span>
          </p>
          <p className="text-sm text-muted-foreground mt-1">
            The target spend of <span className="font-medium text-foreground">$10,000</span> cannot be reached due to existing budget limits. <span className="text-primary hover:underline cursor-pointer">Adjust limits</span> to recalculate suggestions.
          </p>
        </div>
      </div>

      {/* Tabs for table */}
      <div className="max-w-7xl mx-auto px-6 pt-6">
        <div className="flex gap-4 border-b border-border">
          <button className="py-2 text-sm font-medium text-foreground border-b-2 border-foreground">
            ☰ Individual Budgets
          </button>
          <button className="py-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            📊 Summary & Media Mix charts
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="rounded-lg border border-border bg-card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-muted/50 border-b border-border">
                <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Budget Name
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Channel
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Period
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Current
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  New Budget
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Change
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Cost
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {budgets.map((budget, idx) => (
                <tr key={idx} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 text-sm text-foreground">{budget.name}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{budget.channel}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{budget.period}</td>
                  <td className="px-4 py-3 text-sm text-right text-muted-foreground">${budget.current}</td>
                  <td className="px-4 py-3 text-right">
                    <input
                      type="number"
                      value={budget.new}
                      className="w-20 px-2 py-1 text-sm text-right rounded border border-warning/30 bg-warning/10 focus:outline-none focus:ring-1 focus:ring-warning"
                      readOnly
                    />
                  </td>
                  <td className={cn(
                    "px-4 py-3 text-sm text-right font-medium",
                    budget.change > 0 ? "text-success" : "text-destructive"
                  )}>
                    {budget.change > 0 ? "▲" : "▼"} {Math.abs(budget.change)}%
                  </td>
                  <td className="px-4 py-3 text-sm text-right text-muted-foreground">${budget.cost}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
