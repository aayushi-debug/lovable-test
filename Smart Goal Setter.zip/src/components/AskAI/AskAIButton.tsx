import { forwardRef } from "react";
import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

interface AskAIButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  onClick: () => void;
  isExpanded: boolean;
  disabled?: boolean;
  className?: string;
}

export const AskAIButton = forwardRef<HTMLButtonElement, AskAIButtonProps>(
  ({ onClick, isExpanded, disabled, className, ...props }, ref) => {
    return (
      <button
        ref={ref}
        onClick={onClick}
        disabled={disabled}
        className={cn(
          "inline-flex items-center gap-2 px-3 py-1.5 text-sm font-medium",
          "rounded-md border transition-all duration-200",
          "bg-card text-muted-foreground border-border",
          "hover:bg-ai-surface hover:border-ai-border hover:text-ai-accent",
          "focus:outline-none focus:ring-2 focus:ring-ai-accent focus:ring-offset-1",
          "disabled:opacity-50 disabled:cursor-not-allowed",
          isExpanded && "bg-ai-surface border-ai-border text-ai-accent",
          className
        )}
        {...props}
      >
        <Sparkles className={cn(
          "h-4 w-4 transition-all duration-200",
          isExpanded && "animate-sparkle"
        )} />
        <span>Ask AI</span>
      </button>
    );
  }
);

AskAIButton.displayName = "AskAIButton";