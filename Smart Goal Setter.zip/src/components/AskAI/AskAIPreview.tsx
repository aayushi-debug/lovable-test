 import { Check, AlertCircle, ArrowRight } from "lucide-react";
 import { cn } from "@/lib/utils";
 import type { AskAIResult } from "./types";
 
 interface AskAIPreviewProps {
   result: AskAIResult;
   onApply: () => void;
   onDiscard: () => void;
   isApplying?: boolean;
 }
 
 export function AskAIPreview({ result, onApply, onDiscard, isApplying }: AskAIPreviewProps) {
   const confidenceColors = {
     high: "text-success",
     medium: "text-warning",
     low: "text-destructive",
   };
 
    return (
      <div className="space-y-3">
        {/* Summary */}
        <div className="flex items-start gap-2">
          <AlertCircle className="h-4 w-4 text-ai-accent mt-0.5 shrink-0" />
          <p className="text-sm text-foreground">{result.summary}</p>
        </div>

        {/* Changes as readable text */}
        <div className="space-y-1.5 pl-6">
          {result.changes.map((change, index) => (
            <p key={index} className="text-sm text-muted-foreground">
              <span className="font-medium text-foreground">{change.label}</span>{" "}
              will change from{" "}
              <span className="line-through">{String(change.previousValue)}{change.unit && ` ${change.unit}`}</span>{" "}
              <ArrowRight className="inline h-3 w-3 text-muted-foreground mx-0.5" />{" "}
              <span className="font-medium text-success">{String(change.newValue)}{change.unit && ` ${change.unit}`}</span>
            </p>
          ))}
        </div>

        <p className={cn("text-xs pl-6", confidenceColors[result.confidence])}>
          {result.confidence === "high" && "High confidence match"}
          {result.confidence === "medium" && "Medium confidence — review suggested changes"}
          {result.confidence === "low" && "Low confidence — please review carefully"}
        </p>
      </div>
    );
  }