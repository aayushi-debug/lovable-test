 export interface AskAIContext {
   toolName: string;
   availableSettings: SettingDefinition[];
   scope: 'account' | 'portfolio' | 'selection' | 'custom';
   scopeLabel?: string;
   supportedActions: string[];
 }
 
 export interface SettingDefinition {
   key: string;
   label: string;
   type: 'select' | 'number' | 'boolean' | 'text' | 'range';
   options?: { value: string; label: string }[];
   min?: number;
   max?: number;
   unit?: string;
   currentValue?: string | number | boolean;
 }
 
 export interface SettingChange {
   key: string;
   label: string;
   previousValue: string | number | boolean;
   newValue: string | number | boolean;
   unit?: string;
 }
 
 export interface AskAIResult {
   changes: SettingChange[];
   summary: string;
   confidence: 'high' | 'medium' | 'low';
 }