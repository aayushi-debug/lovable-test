 import { useState, useCallback } from "react";
 import { Collapsible, CollapsibleContent } from "@/components/ui/collapsible";
 import { cn } from "@/lib/utils";
 import { AskAIButton } from "./AskAIButton";
 import { AskAIInput } from "./AskAIInput";
 import { AskAIPreview } from "./AskAIPreview";
 import type { AskAIContext, AskAIResult, SettingChange } from "./types";
 
 export interface AskAIProps {
   context: AskAIContext;
   onApplyChanges?: (changes: SettingChange[]) => void;
   onTranslate?: (prompt: string, context: AskAIContext) => Promise<AskAIResult>;
   className?: string;
   inputPlaceholder?: string;
   helperText?: string;
 }
 
 // Default mock translator for demo purposes
 const defaultTranslator = async (prompt: string, context: AskAIContext): Promise<AskAIResult> => {
   // Simulate API delay
   await new Promise((resolve) => setTimeout(resolve, 1500));
 
   // Generate mock changes based on context
   const changes: SettingChange[] = context.availableSettings.slice(0, 3).map((setting) => {
     let newValue: string | number | boolean = setting.currentValue ?? "";
     
     if (setting.type === "number" && typeof setting.currentValue === "number") {
       newValue = Math.round(setting.currentValue * 1.2);
     } else if (setting.type === "select" && setting.options?.length) {
       newValue = setting.options[Math.floor(Math.random() * setting.options.length)].value;
     } else if (setting.type === "boolean") {
       newValue = !setting.currentValue;
     }
 
     return {
       key: setting.key,
       label: setting.label,
       previousValue: setting.currentValue ?? "Not set",
       newValue,
       unit: setting.unit,
     };
   });
 
   return {
     changes,
     summary: `Interpreted: "${prompt}" → Adjusting ${changes.length} settings for ${context.toolName}`,
     confidence: "high" as const,
   };
 };
 
 export function AskAI({
   context,
   onApplyChanges,
   onTranslate = defaultTranslator,
   className,
   inputPlaceholder,
   helperText,
 }: AskAIProps) {
   const [isExpanded, setIsExpanded] = useState(false);
   const [isLoading, setIsLoading] = useState(false);
   const [result, setResult] = useState<AskAIResult | null>(null);
 
   const handleToggle = useCallback(() => {
     if (isExpanded) {
       setIsExpanded(false);
       setResult(null);
     } else {
       setIsExpanded(true);
     }
   }, [isExpanded]);
 
   const handleSubmit = useCallback(async (prompt: string) => {
     setIsLoading(true);
     try {
       const translatedResult = await onTranslate(prompt, context);
       setResult(translatedResult);
     } catch (error) {
       console.error("Failed to translate prompt:", error);
     } finally {
       setIsLoading(false);
     }
   }, [context, onTranslate]);
 
   const handleApply = useCallback(() => {
     if (result?.changes && onApplyChanges) {
       onApplyChanges(result.changes);
     }
     setIsExpanded(false);
     setResult(null);
   }, [result, onApplyChanges]);
 
   const handleCancel = useCallback(() => {
     setIsExpanded(false);
     setResult(null);
   }, []);
 
   const handleDiscard = useCallback(() => {
     setResult(null);
   }, []);
 
   return (
     <div className={cn("relative", className)}>
       <AskAIButton
         onClick={handleToggle}
         isExpanded={isExpanded}
         disabled={isLoading}
       />
 
       <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
         <CollapsibleContent className="overflow-hidden data-[state=open]:animate-slide-down data-[state=closed]:animate-slide-up">
           <div className="mt-3 p-4 rounded-lg border border-ai-border bg-card shadow-sm">
             {result ? (
               <AskAIPreview
                 result={result}
                 onApply={handleApply}
                 onDiscard={handleDiscard}
               />
             ) : (
               <AskAIInput
                 placeholder={inputPlaceholder}
                 helperText={helperText}
                 onSubmit={handleSubmit}
                 onCancel={handleCancel}
                 isLoading={isLoading}
               />
             )}
           </div>
         </CollapsibleContent>
       </Collapsible>
     </div>
   );
 }
 
 export type { AskAIContext, AskAIResult, SettingChange } from "./types";