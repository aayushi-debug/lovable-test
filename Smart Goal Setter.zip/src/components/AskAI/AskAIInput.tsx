 import { useState } from "react";
 import { Play, X, Loader2 } from "lucide-react";
 import { cn } from "@/lib/utils";
 
 interface AskAIInputProps {
   placeholder?: string;
   helperText?: string;
   onSubmit: (prompt: string) => void;
   onCancel: () => void;
   isLoading?: boolean;
 }
 
 export function AskAIInput({
   placeholder = "Describe your goal, e.g. 'Hit $5,000 spend and maximize conversions'",
   helperText = "We'll convert this into optimization settings",
   onSubmit,
   onCancel,
   isLoading = false,
 }: AskAIInputProps) {
   const [value, setValue] = useState("");
 
   const handleSubmit = () => {
     if (value.trim() && !isLoading) {
       onSubmit(value.trim());
     }
   };
 
   const handleKeyDown = (e: React.KeyboardEvent) => {
     if (e.key === "Enter" && !e.shiftKey) {
       e.preventDefault();
       handleSubmit();
     }
     if (e.key === "Escape") {
       onCancel();
     }
   };
 
   return (
     <div className="space-y-3">
       <div className="relative">
         <input
           type="text"
           value={value}
           onChange={(e) => setValue(e.target.value)}
           onKeyDown={handleKeyDown}
           placeholder={placeholder}
           disabled={isLoading}
           className={cn(
             "w-full px-4 py-3 pr-24 text-sm rounded-lg",
             "bg-card border border-border",
             "placeholder:text-muted-foreground/60",
             "focus:outline-none focus:ring-2 focus:ring-ai-accent focus:border-transparent",
             "disabled:opacity-50 disabled:cursor-not-allowed",
             "transition-all duration-200"
           )}
           autoFocus
         />
         <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
           <button
             onClick={onCancel}
             disabled={isLoading}
             className={cn(
               "p-1.5 rounded-md text-muted-foreground",
               "hover:bg-muted hover:text-foreground",
               "transition-colors duration-150",
               "disabled:opacity-50"
             )}
             title="Cancel"
           >
             <X className="h-4 w-4" />
           </button>
           <button
             onClick={handleSubmit}
             disabled={!value.trim() || isLoading}
             className={cn(
               "p-1.5 rounded-md",
               "bg-ai-accent text-white",
               "hover:bg-ai-accent/90",
               "disabled:opacity-50 disabled:cursor-not-allowed",
               "transition-all duration-150"
             )}
             title="Submit"
           >
             {isLoading ? (
               <Loader2 className="h-4 w-4 animate-spin" />
             ) : (
               <Play className="h-4 w-4 fill-current" />
             )}
           </button>
         </div>
       </div>
       <p className="text-xs text-muted-foreground px-1">{helperText}</p>
     </div>
   );
 }