import { forwardRef } from "react";
import { cn } from "@/lib/utils";

interface AskAITargetAreaProps {
  children: React.ReactNode;
  isHighlighted?: boolean;
  className?: string;
}

export const AskAITargetArea = forwardRef<HTMLDivElement, AskAITargetAreaProps>(
  ({ children, isHighlighted, className }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          "relative transition-all duration-200 rounded-lg",
          isHighlighted && [
            "ring-2 ring-ai-accent ring-offset-2 ring-offset-background",
            "bg-card shadow-lg shadow-ai-glow/10",
            "z-50",
          ],
          className
        )}
      >
        {children}
      </div>
    );
  }
);

AskAITargetArea.displayName = "AskAITargetArea";
