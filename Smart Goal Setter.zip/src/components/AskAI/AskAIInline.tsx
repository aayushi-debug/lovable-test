import { useState, useCallback, useRef, useEffect } from "react";
import { Loader2, Sparkles, Eye, Check, RefreshCw } from "lucide-react";
import { cn } from "@/lib/utils";
import { AskAIPreview } from "./AskAIPreview";
import type { AskAIContext, AskAIResult, SettingChange } from "./types";

export interface AskAIInlineProps {
  context: AskAIContext;
  onApplyChanges?: (changes: SettingChange[]) => void;
  onTranslate?: (prompt: string, context: AskAIContext) => Promise<AskAIResult>;
  className?: string;
  helperText?: string;
  examplePrompts?: string[];
  /** The settings panel to render below the input; preview overlays on top of it */
  children?: React.ReactNode;
}

const defaultTranslator = async (prompt: string, context: AskAIContext): Promise<AskAIResult> => {
  await new Promise((resolve) => setTimeout(resolve, 1500));
  const changes: SettingChange[] = context.availableSettings.slice(0, 3).map((setting) => {
    let newValue: string | number | boolean = setting.currentValue ?? "";
    if (setting.type === "number" && typeof setting.currentValue === "number") {
      newValue = Math.round(setting.currentValue * 1.2);
    } else if (setting.type === "select" && setting.options?.length) {
      newValue = setting.options[Math.floor(Math.random() * setting.options.length)].value;
    } else if (setting.type === "boolean") {
      newValue = !setting.currentValue;
    }
    return {
      key: setting.key,
      label: setting.label,
      previousValue: setting.currentValue ?? "Not set",
      newValue,
      unit: setting.unit,
    };
  });
  return {
    changes,
    summary: `Interpreted: "${prompt}" → Adjusting ${changes.length} settings for ${context.toolName}`,
    confidence: "high" as const,
  };
};

const DEFAULT_EXAMPLES = [
  "Hit $5,000 spend and maximize conversions",
  "Reallocate budgets to better performing platform",
  "Reduce spend on underperforming campaigns by 20%",
  "Maximize ROAS while keeping spend under $8,000",
];

export function AskAIInline({
  context,
  onApplyChanges,
  onTranslate = defaultTranslator,
  className,
  helperText = "We'll convert this into optimization settings",
  examplePrompts = DEFAULT_EXAMPLES,
  children,
}: AskAIInlineProps) {
  const [query, setQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<AskAIResult | null>(null);
  const [lastSubmittedQuery, setLastSubmittedQuery] = useState("");
  const [isReloading, setIsReloading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Rotating ghost text state
  const [currentExampleIndex, setCurrentExampleIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState("");
  const [isTyping, setIsTyping] = useState(true);

  // Typing animation effect
  useEffect(() => {
    if (query) return;
    const example = examplePrompts[currentExampleIndex];
    let charIndex = 0;
    let timeoutId: ReturnType<typeof setTimeout>;

    if (isTyping) {
      const typeChar = () => {
        if (charIndex <= example.length) {
          setDisplayedText(example.slice(0, charIndex));
          charIndex++;
          timeoutId = setTimeout(typeChar, 40 + Math.random() * 30);
        } else {
          timeoutId = setTimeout(() => setIsTyping(false), 2000);
        }
      };
      typeChar();
    } else {
      let eraseIndex = example.length;
      const eraseChar = () => {
        if (eraseIndex >= 0) {
          setDisplayedText(example.slice(0, eraseIndex));
          eraseIndex--;
          timeoutId = setTimeout(eraseChar, 20);
        } else {
          setCurrentExampleIndex((prev) => (prev + 1) % examplePrompts.length);
          setIsTyping(true);
        }
      };
      eraseChar();
    }
    return () => clearTimeout(timeoutId);
  }, [query, currentExampleIndex, isTyping, examplePrompts]);

  const handleSubmit = useCallback(async () => {
    if (!query.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const translatedResult = await onTranslate(query.trim(), context);
      setResult(translatedResult);
      setLastSubmittedQuery(query.trim());
    } catch (error) {
      console.error("Failed to translate prompt:", error);
    } finally {
      setIsLoading(false);
    }
  }, [query, isLoading, context, onTranslate]);

  const handleApply = useCallback(() => {
    if (result?.changes && onApplyChanges) {
      onApplyChanges(result.changes);
    }
    setResult(null);
    setQuery("");
    setLastSubmittedQuery("");
    // Trigger reload animation
    setIsReloading(true);
    setTimeout(() => setIsReloading(false), 1200);
  }, [result, onApplyChanges]);

  const handleDiscard = useCallback(() => {
    setResult(null);
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const previewDisabled = !query.trim() || isLoading || (!!result && query.trim() === lastSubmittedQuery);

  return (
    <div className={cn("space-y-3", className)}>
      {/* Input with inline Preview button */}
      <div className="relative">
        <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 pointer-events-none">
          <Sparkles className="h-4 w-4 text-ai-accent" />
        </div>
        {!query && (
          <div className="absolute inset-0 flex items-center pl-9 pr-24 pointer-events-none">
            <span className="text-sm text-muted-foreground/40 truncate">
              {displayedText}
              <span className="inline-block w-px h-4 bg-muted-foreground/30 ml-0.5 animate-pulse align-text-bottom" />
            </span>
          </div>
        )}
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={isLoading}
          className={cn(
            "w-full pl-9 pr-24 py-2.5 text-sm rounded-lg",
            "bg-background border border-border",
            "focus:outline-none focus:ring-2 focus:ring-ai-accent focus:border-transparent",
            "disabled:opacity-50 disabled:cursor-not-allowed",
            "transition-all duration-200"
          )}
        />
        <div className="absolute right-2 top-1/2 -translate-y-1/2">
          <button
            onClick={handleSubmit}
            disabled={previewDisabled}
            className={cn(
              "inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md",
              "transition-all duration-150",
              previewDisabled
                ? "bg-muted text-muted-foreground cursor-not-allowed opacity-60"
                : "bg-ai-accent text-white hover:bg-ai-accent/90"
            )}
          >
            {isLoading ? (
              <>
                <Loader2 className="h-3 w-3 animate-spin" />
                Generating…
              </>
            ) : (
              <>
                <Eye className="h-3 w-3" />
                Preview
              </>
            )}
          </button>
        </div>
      </div>

      {/* Settings panel wrapper with overlay capability */}
      {children && (
        <div className="relative">
          {/* Settings content */}
          <div
            className={cn(
              "transition-all duration-500",
              isReloading && "opacity-30 blur-[1px]"
            )}
          >
            {children}
          </div>

          {/* Reload overlay animation */}
          {isReloading && (
            <div className="absolute inset-0 flex items-center justify-center z-10 animate-in fade-in-0 duration-200">
              <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card border border-border shadow-lg">
                <RefreshCw className="h-4 w-4 text-ai-accent animate-spin" />
                <span className="text-sm font-medium text-foreground">Updating settings…</span>
              </div>
            </div>
          )}

          {/* Preview result overlay on settings */}
          {result && (
            <div className="absolute inset-0 z-20 animate-in fade-in-0 slide-in-from-top-2 duration-200">
              <div className="p-4 rounded-lg border-2 border-ai-accent bg-card shadow-xl h-full overflow-auto space-y-3">
                <AskAIPreview
                  result={result}
                  onApply={handleApply}
                  onDiscard={handleDiscard}
                />
                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    onClick={handleDiscard}
                    className={cn(
                      "px-3 py-1.5 text-xs font-medium rounded-md",
                      "text-muted-foreground hover:bg-muted hover:text-foreground",
                      "transition-colors duration-150"
                    )}
                  >
                    Discard
                  </button>
                  <button
                    onClick={handleApply}
                    className={cn(
                      "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md",
                      "bg-success text-success-foreground hover:bg-success/90",
                      "transition-all duration-150"
                    )}
                  >
                    <Check className="h-3.5 w-3.5" />
                    Update Settings
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
