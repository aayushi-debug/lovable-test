import { useState, useCallback, useRef, useEffect } from "react";
import { X, Loader2, Clock, Sparkles, Eye, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { AskAIButton } from "./AskAIButton";
import { AskAIPreview } from "./AskAIPreview";
import type { AskAIContext, AskAIResult, SettingChange } from "./types";

export interface AskAIOverlayProps {
  context: AskAIContext;
  onApplyChanges?: (changes: SettingChange[]) => void;
  onTranslate?: (prompt: string, context: AskAIContext) => Promise<AskAIResult>;
  className?: string;
  inputPlaceholder?: string;
  helperText?: string;
  targetRef?: React.RefObject<HTMLElement>;
  children?: React.ReactNode;
}

const defaultTranslator = async (prompt: string, context: AskAIContext): Promise<AskAIResult> => {
  await new Promise((resolve) => setTimeout(resolve, 1500));

  const changes: SettingChange[] = context.availableSettings.slice(0, 3).map((setting) => {
    let newValue: string | number | boolean = setting.currentValue ?? "";
    if (setting.type === "number" && typeof setting.currentValue === "number") {
      newValue = Math.round(setting.currentValue * 1.2);
    } else if (setting.type === "select" && setting.options?.length) {
      newValue = setting.options[Math.floor(Math.random() * setting.options.length)].value;
    } else if (setting.type === "boolean") {
      newValue = !setting.currentValue;
    }
    return {
      key: setting.key,
      label: setting.label,
      previousValue: setting.currentValue ?? "Not set",
      newValue,
      unit: setting.unit,
    };
  });

  return {
    changes,
    summary: `Interpreted: "${prompt}" → Adjusting ${changes.length} settings for ${context.toolName}`,
    confidence: "high" as const,
  };
};

const HISTORY_KEY = "ask-ai-query-history";
const MAX_HISTORY = 3;

function getQueryHistory(): string[] {
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
  } catch {
    return [];
  }
}

function saveQueryToHistory(query: string) {
  const history = getQueryHistory().filter((q) => q !== query);
  history.unshift(query);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, MAX_HISTORY)));
}

export function AskAIOverlay({
  context,
  onApplyChanges,
  onTranslate = defaultTranslator,
  className,
  inputPlaceholder = "Describe your goal, e.g. 'Hit $5,000 spend and maximize conversions'",
  helperText = "We'll convert this into optimization settings",
  targetRef,
  children,
}: AskAIOverlayProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<AskAIResult | null>(null);
  const [lastSubmittedQuery, setLastSubmittedQuery] = useState("");
  const [query, setQuery] = useState("");
  const [queryHistory, setQueryHistory] = useState<string[]>(getQueryHistory);
  const overlayRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleToggle = useCallback(() => {
    if (isExpanded) {
      setIsExpanded(false);
      setResult(null);
      setQuery("");
    } else {
      setIsExpanded(true);
      setQueryHistory(getQueryHistory());
    }
  }, [isExpanded]);

  const handleSubmit = useCallback(async () => {
    if (!query.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const translatedResult = await onTranslate(query.trim(), context);
      setResult(translatedResult);
      setLastSubmittedQuery(query.trim());
      saveQueryToHistory(query.trim());
      setQueryHistory(getQueryHistory());
    } catch (error) {
      console.error("Failed to translate prompt:", error);
    } finally {
      setIsLoading(false);
    }
  }, [query, isLoading, context, onTranslate]);

  const handleApply = useCallback(() => {
    if (result?.changes && onApplyChanges) {
      onApplyChanges(result.changes);
    }
    setIsExpanded(false);
    setResult(null);
    setQuery("");
  }, [result, onApplyChanges]);

  const handleCancel = useCallback(() => {
    setIsExpanded(false);
    setResult(null);
    setQuery("");
  }, []);

  const handleDiscard = useCallback(() => {
    setResult(null);
  }, []);

  const handleSelectHistory = useCallback((historyQuery: string) => {
    setQuery(historyQuery);
    setResult(null);
    setTimeout(() => inputRef.current?.focus(), 0);
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
    if (e.key === "Escape") {
      handleCancel();
    }
  };

  // Focus input when expanded
  useEffect(() => {
    if (isExpanded) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isExpanded]);

  // Close on escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isExpanded) handleCancel();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [isExpanded, handleCancel]);

  // Close on click outside
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (
        isExpanded &&
        overlayRef.current &&
        !overlayRef.current.contains(e.target as Node) &&
        !(e.target as Element)?.closest("[data-ask-ai-button]")
      ) {
        handleCancel();
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [isExpanded, handleCancel]);

  // Calculate overlay position: cover the target area from the left
  const getOverlayStyle = (): React.CSSProperties => {
    if (!targetRef?.current) return { top: "50%", left: "50%", transform: "translate(-50%, -50%)" };
    const rect = targetRef.current.getBoundingClientRect();
    return {
      top: rect.top,
      left: rect.left,
      width: rect.width,
      minHeight: rect.height,
    };
  };

  return (
    <>
      <AskAIButton
        ref={buttonRef}
        onClick={handleToggle}
        isExpanded={isExpanded}
        disabled={isLoading}
        className={className}
        data-ask-ai-button
      />

      {isExpanded && (
        <>
          {/* Backdrop */}
          <div className="fixed inset-0 z-40 bg-black/40" onClick={handleCancel} aria-hidden="true" />

          {/* Overlay panel - positioned over the target area */}
          <div
            ref={overlayRef}
            className={cn(
              "fixed z-50 flex flex-col",
              "animate-in fade-in-0 zoom-in-[0.98] duration-200"
            )}
            style={getOverlayStyle()}
          >
            <div className="p-5 rounded-lg border-2 border-ai-accent bg-card shadow-2xl shadow-ai-glow/20 flex flex-col gap-4 h-full">
              {/* Header */}
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-ai-accent animate-sparkle" />
                <span className="text-sm font-medium text-foreground">Ask AI</span>
                <button
                  onClick={handleCancel}
                  className="ml-auto p-1 rounded-md text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Input field - always visible and editable */}
              <div className="relative">
                <input
                  ref={inputRef}
                  type="text"
                  value={query}
                  onChange={(e) => {
                    setQuery(e.target.value);
                  }}
                  onKeyDown={handleKeyDown}
                  placeholder={inputPlaceholder}
                  disabled={isLoading}
                  className={cn(
                    "w-full px-4 py-3 text-sm rounded-lg",
                    "bg-background border border-border",
                    "placeholder:text-muted-foreground/60",
                    "focus:outline-none focus:ring-2 focus:ring-ai-accent focus:border-transparent",
                    "disabled:opacity-50 disabled:cursor-not-allowed",
                    "transition-all duration-200"
                  )}
                />
              </div>

              <p className="text-xs text-muted-foreground -mt-2 px-1">{helperText}</p>

              {/* Generate Preview button */}
              <div className="flex justify-end">
                <button
                  onClick={handleSubmit}
                  disabled={!query.trim() || isLoading || (!!result && query.trim() === lastSubmittedQuery)}
                  className={cn(
                    "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md",
                    "transition-all duration-150",
                    !query.trim() || (!!result && query.trim() === lastSubmittedQuery)
                      ? "bg-muted text-muted-foreground cursor-not-allowed opacity-60"
                      : "bg-ai-accent text-white hover:bg-ai-accent/90",
                    isLoading && "opacity-70 cursor-not-allowed"
                  )}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      Generating…
                    </>
                  ) : (
                    <>
                      <Eye className="h-3.5 w-3.5" />
                      Generate Preview
                    </>
                  )}
                </button>
              </div>

              {/* Result preview - shown inline below input */}
              {result && (
                <div className="animate-in fade-in-0 slide-in-from-top-2 duration-200 space-y-3">
                  <AskAIPreview
                    result={result}
                    onApply={handleApply}
                    onDiscard={handleDiscard}
                  />
                  {/* Apply / Discard CTAs */}
                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={handleDiscard}
                      className={cn(
                        "px-3 py-1.5 text-xs font-medium rounded-md",
                        "text-muted-foreground hover:bg-muted hover:text-foreground",
                        "transition-colors duration-150"
                      )}
                    >
                      Discard
                    </button>
                    <button
                      onClick={handleApply}
                      className={cn(
                        "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md",
                        "bg-success text-success-foreground hover:bg-success/90",
                        "transition-all duration-150"
                      )}
                    >
                      <Check className="h-3.5 w-3.5" />
                      Update Settings
                    </button>
                  </div>
                </div>
              )}

              {/* Previous queries section - shown when no result */}
              {!result && queryHistory.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>Recent queries</span>
                  </div>
                  <div className="space-y-1">
                    {queryHistory.map((historyQuery, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSelectHistory(historyQuery)}
                        className={cn(
                          "w-full text-left px-3 py-2 text-sm rounded-md",
                          "text-muted-foreground hover:text-foreground",
                          "hover:bg-muted/80 transition-colors duration-150",
                          "truncate block"
                        )}
                      >
                        {historyQuery}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </>
  );
}
